package fpgaintel

// API parameters
const (
	GroupName = "fpga.intel.com"
)
