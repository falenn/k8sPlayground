// +k8s:deepcopy-gen=package,register

// +groupName=fpga.intel.com

package v1
